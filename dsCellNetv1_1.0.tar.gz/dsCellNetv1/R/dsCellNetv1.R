#-------------
#TITLE:tsCCNet
#Author:SZH
#TIME:2021/5
#-------------
##load library
#########R4.0.3
if(!require("igraph", quietly = TRUE))
	        install.packages("igraph")
if(!require("homologene", quietly = TRUE))
	        install.packages("homologene")
if(!require("Hmisc", quietly = TRUE))
	        install.packages("Hmisc")
if(!require("ggpubr", quietly = TRUE))
	        install.packages("ggpubr")
if(!require("pheatmap", quietly = TRUE))
	        install.packages("pheatmap")
if(!require("reshape2", quietly = TRUE))
	        install.packages("reshape2")
if(!require("ggalluvial", quietly = TRUE))
	        install.packages("ggalluvial")
if(!require("tseries", quietly = TRUE))
	        install.packages("tseries")
if(!require("purrr", quietly = TRUE))
	        install.packages("purrr")

library(igraph)
library(homologene)
library(Hmisc)
library(ggpubr)
library(pheatmap)
library(reshape2)
library(ggalluvial)
#library(parallel)
library(tseries)
library(purrr)

#load db-color
dbloc="./database/"
load(paste(dbloc,"tsCCNETcolor.RData",sep=""))
#load db-membrane/secret data and LR pairs
load(paste(dbloc,"membrane_protein_mouse.RData",sep="")) #memsercpros
load(paste(dbloc,"secreted_protein_mouse.RData",sep="")) #sercpros


##load function
normalized<-function(x){
  y<-(x-min(x))/(max(x)-min(x))
  return(y)
}

#homologous genes
# aimspecies<-"Mus musculus"
# sourcespecies<-"Homo sapiens"
convertGeneList <- function(x,sourcespecies,aimspecies){
  speciesid<-homologene::taxData$tax_id[homologene::taxData$name_txt==sourcespecies]
  aimspeciesid<-homologene::taxData$tax_id[homologene::taxData$name_txt==aimspecies]
  memout<-homologene(x,inTax = speciesid,outTax = aimspeciesid)
  genesV2<-na.omit(memout[,1:2])
  
  humanx <- genesV2[, 2]
  names(humanx)<-genesV2[,1]
  # Print the first 6 genes found to the screen
  print(head(humanx))
  return(humanx)
}

datainput<-function(datloc,expnam,typnam,timnam,ifQC,resloc){
  #prepare result location
  shell_cmd<-paste("mkdir ",resloc,sep = "")
  grep_out<-system(shell_cmd, intern = TRUE)
  cat(grep_out)
  shell_cmd<-paste("mkdir ",resloc,"tmp",sep = "")
  grep_out<-system(shell_cmd, intern = TRUE)
  cat(grep_out)
  tmploc=paste(resloc,"tmp",sep = "")
  #load data
  datexp<-read.csv(paste(datloc,expnam,sep=""),check.names = F,header = T,row.names = 1)
  dattyp<-read.csv(paste(datloc,typnam,sep=""),check.names = F,header = T,row.names = 1)
  dattim<-read.csv(paste(datloc,timnam,sep=""),check.names = F,header = T,row.names = 1)
  out<-list()
  #if need to filter or scale data?
  if(ifQC=="True"|ifQC=="TRUE"){
    colnamytyp<-colnames(ytyp)
    colnamytim<-colnames(ytim)
    ###1.Filter according to the sequencing depth of each cell,at least have 5k mapped reads;CPM
    sumCols<-colSums(y)
    print(paste("Quality control:dimension of data(raw) is ",dim(y)[1],dim(y)[2],sep=" "))
    y<-y[,sumCols>5000]
    ytyp<-as.data.frame(ytyp[sumCols>5000,])
    ytim<-as.data.frame(ytim[sumCols>5000,])
    print(paste("Quality control:dimension of data(at least 5K reads) is ",dim(y)[1],dim(y)[2],sep=" "))
    seqdepth<-colSums(y)/10^6
    y<-sweep(y,2,seqdepth,"/")
    print("Quality control:remove sequence depth among cells")
    ###2.Control expressed gene and cells
    genenum<-apply(y,1,function(x) sum(x>0))
    y<-y[genenum>5,]
    print(paste("Quality control:dimension of data(at least express 5 cells) is ",dim(y)[1],dim(y)[2],sep=" "))
    celnum<-apply(y,2,function(x) sum(x>0))
    y<-y[,celnum>500]
    ytyp<-as.data.frame(ytyp[celnum>500,])
    ytim<-as.data.frame(ytim[celnum>500,])
    colnames(ytyp)<-colnamytyp
    rownames(ytyp)<-colnames(y)
    colnames(ytim)<-colnamytim
    rownames(ytim)<-colnames(y)
    print(paste("Quality control:dimension of data(at least express 500 genes) is ",dim(y)[1],dim(y)[2],sep=" "))
    out$exp<-y
    out$typ<-ytyp
    out$tim<-ytim
    return(out)
  }else if(ifQC=="False"|ifQC=="FALSE"){
    out$exp<-datexp
    out$typ<-dattyp
    out$tim<-dattim
    return(out)
  }
  print("Finish quality control!") 
}

memserchomotrans<-function(mempros,sercpros,aimspecies){
  sourcespecies<-"Mus musculus"
  aimnam<-substr(aimspecies, 1, 3)
  memsercpros<-list()
  #b.homology gene for membrane/secreted and pairsdata
  if(aimspecies!="Mus musculus" & aimspecies %in% homologene::taxData$name_txt){
    memout<-convertGeneList(mempros,sourcespecies,aimspecies)
    memprot<-na.omit(memout)
    sercout<-convertGeneList(sercpros,sourcespecies,aimspecies)
    sercprot<-na.omit(sercout)
    memsercpros$memprot<-memprot
    memsercpros$sercprot<-sercprot
    print(paste("Step0:Number of used membrane/secreted proteins of",aimnam,"is ",length(memprot),length(sercprot),sep=" "))
    return(memsercpros)
  }else if(aimspecies=="Mus musculus"){
    memprot<-mempros
    sercprot<-sercpros 
    memsercpros$memprot<-memprot
    memsercpros$sercprot<-sercprot
    print(paste("Step0:Number of used membrane/secreted proteins of",aimnam,"is ",length(memprot),length(sercprot),sep=" "))
    return(memsercpros)
  }else{
    print("Error1:check the species dataset name or don't support this species! Avaliable species:") 
    print(homologene::taxData$name_txt)
    #print("Check species dataset name, using:totalspecies()")
    break  
  }
}

LRdbhomotrans<-function(yexp,mempros,sercpros,aimspecies,dbloc){
  sourcespecies="Homo sapiens"
  aimnam<-substr(aimspecies, 1, 3)
  #b.homology gene for membrane/secreted and pairsdata
  if(!(aimspecies %in% c("Homo sapiens","Mus musculus")) & aimspecies %in% homologene::taxData$name_txt){
    memprot<-mempros
    sercprot<-sercpros
    #a.trans form pairs genes
    load(paste(dbloc,"lr-tsCC-human.Rdata",sep=""))
    pairsdata<-tsCCPairsDb
    genel<-as.character(unlist(pairsdata[,1]))
    gener<-as.character(unlist(pairsdata[,2]))
    genelout<-convertGeneList(genel,sourcespecies,aimspecies)
    generout<-convertGeneList(gener,sourcespecies,aimspecies)
    res<-tsCCPairsDb
    res$Ligand<-genelout[pairsdata[,1]]
    res$Receptor<-generout[pairsdata[,2]]
    usedpairsdata0<-na.omit(res)
    
    memprot<-mempros
    sercprot<-sercpros 
    print(paste("Step1:dimension of used L&R pairs of",aimnam,"is ",dim(usedpairsdata0)[1],sep=" "))
    #b.kept genes in user's data
    usedpairsdata1<-usedpairsdata0[(usedpairsdata0[,1] %in% rownames(yexp))  & (usedpairsdata0[,2] %in% rownames(yexp)),]
    #c.kept genes(L:m+s;R:m)
    usedpairsdata<-usedpairsdata1[(usedpairsdata1[,1] %in% unique(c(memprot,sercprot)))  & (usedpairsdata1[,2] %in% unique(memprot)),]
    return(usedpairsdata)
    print(paste("Step1:dimension of expressed L&R pairs of",aimnam,"is ",dim(usedpairsdata)[1],sep=" "))
    print(paste("Step1:dimension of expressed L R genes of",aimnam,"is ",length(unique(usedpairsdata[,1])),length(unique(usedpairsdata[,2])),sep=" "))
    
  }else if(aimspecies %in% c("Homo sapiens","Mus musculus")){
    if(aimspecies=="Homo sapiens"){
      load(paste(dbloc,"lr-tsCC-human.Rdata",sep=""))
      usedpairsdata0<-tsCCPairsDb
    }else if(aimspecies=="Mus musculus"){
      load(paste(dbloc,"lr-tsCC-mouse.Rdata",sep=""))
      usedpairsdata0<-tsCCPairsDb
    }
    
    memprot<-mempros
    sercprot<-sercpros 
    print(paste("Step1:dimension of used L&R pairs of",aimnam,"is ",dim(usedpairsdata0)[1],sep=" "))
    #b.kept genes in user's data
    usedpairsdata1<-usedpairsdata0[(usedpairsdata0[,1] %in% rownames(yexp))  & (usedpairsdata0[,2] %in% rownames(yexp)),]
    #c.kept genes(L:m+s;R:m)
    usedpairsdata<-usedpairsdata1[(usedpairsdata1[,1] %in% unique(c(memprot,sercprot)))  & (usedpairsdata1[,2] %in% unique(memprot)),]
    return(usedpairsdata)
    print(paste("Step1:dimension of expressed L&R pairs of",aimnam,"is ",dim(usedpairsdata)[1],sep=" "))
    print(paste("Step1:dimension of expressed L R genes of",aimnam,"is ",length(unique(usedpairsdata[,1])),length(unique(usedpairsdata[,2])),sep=" "))
    
  }else{
    print("Error1:missing this species! Avaliable species:") 
    print(homologene::taxData$name_txt)
    break  
  }
}

select_base_exp<-function(inputs){
  n=0
  inputs$Group.1<-as.character(inputs$Group.1) #type
  inputs$Group.2<-as.character(inputs$Group.2) #time
  inputs$variable<-as.character(inputs$variable) #gene
  inputs$value<-as.numeric(inputs$value)
  colnames(inputs)<-c("Group.1","Group.2","variable","value")
  outputs<-as.data.frame(matrix(NA,nc=4,nr=1))
  line1<-0
  L1<-inputs
  LL1<-L1
  L1line<-mean(LL1$value)
  s0<-0
  got=0
  if(max(LL1$value)>=L1line & got==0 & L1line!=0){ ##the highest value in total
    for(n in 1:length(which(LL1$value==max(LL1$value)))){ ##multi max value
      line1<-line1+1
      outputs[line1,]=LL1[which(LL1$value==max(LL1$value))[n],] 
      got=1
    }
  }else if(max(LL1$value)>=L1line & got==0 & L1line==0){ #if all is zero ,input null
    
  }else if(max(LL1$value)<L1line & L1line!=0){ ##those sum value higher than mean value
    for(i in 1:dim(LL1)[1]){
      if(s0<L1line & got==0){ 
        line1<-line1+1
        outputs[line1,]=LL1[which(LL1$value==max(LL1$value)),] 
        L1l=which(LL1$value==max(LL1$value))
        s0<-s0+max(LL1$value) #the total value 
        LL1<-LL1[-L1l,] #remove the highest one 
      }else if(s0>=L1line & got==0){
        line1<-line1+1
        outputs[line1,]=LL1[which(LL1$value==max(LL1$value)),] ##the highest value in total
        got=got+1
      }
    }
  }
  return(outputs)
}

select_base_exp_out<-function(Ltmp,Rtmp){
  n=0
  totalLR<-as.data.frame(matrix(NA,nc=8,nr=1))
  colnames(totalLR)<-c("time","Lloc","Lgen","Lexp","Rloc","Rgen","Rexp","type")
  
  #print(paste(unique(Ltmp$Group.2),unique(Rtmp$Group.2),sep=":"))
  if(dim(Rtmp)[1]!=0 & dim(Ltmp)[1]!=0){
    for(ll in 1: dim(Ltmp)[1]){
      for(rr in 1: dim(Rtmp)[1]){
        n=n+1
        totalLR[n,1]=unique(Ltmp$Group.2) #time
        totalLR[n,2]=Ltmp$Group.1[ll] #Lloc
        lg<-sub("\\.[0-9]+","",Ltmp$variable[ll])#sapply(strsplit(Ltmp$variable[ll],".",fixed = T),"[[",1)
        totalLR[n,3]=lg #Lgene
        totalLR[n,4]=Ltmp$value[ll] #Lexp
        totalLR[n,5]=Rtmp$Group.1[rr] #Rloc
        rg<-sub("\\.[0-9]+","",Rtmp$variable[rr])#sapply(strsplit(Rtmp$variable[rr],".",fixed = T),"[[",1)
        totalLR[n,6]=rg #Rgene
        totalLR[n,7]=Rtmp$value[rr] #Rexp
        totalLR[n,8]=paste(Ltmp$Group.1[ll],Rtmp$Group.1[rr],sep=":") #typeL-R
      }
    }
  }
  return(totalLR)
}

# ###########################
otherexp<-function(totalLRone,expsTinp,expsT,genetyp){ #genetyp="Ligand"
  otherexps<-list()
  if(genetyp=="Ligand"){
    inputs<-as.data.frame(t(expsTinp[(as.character(expsT$Type)!=totalLRone$Lloc & as.character(expsT$Time)==totalLRone$time),colnames(expsTinp)==totalLRone$Lgen]))
    lens<-nrow(expsTinp[(as.character(expsT$Type)==totalLRone$Lloc & as.character(expsT$Time)==totalLRone$time),])
  }else if(genetyp=="Receptor"){
    inputs<-as.data.frame(t(expsTinp[(as.character(expsT$Type)!=totalLRone$Rloc & as.character(expsT$Time)==totalLRone$time),colnames(expsTinp)==totalLRone$Rgen]))
    lens<-nrow(expsTinp[(as.character(expsT$Type)==totalLRone$Rloc & as.character(expsT$Time)==totalLRone$time),])
  }
  otherexps$inputs<-inputs
  otherexps$lens<-lens
  return(otherexps)
}

select_base_pval<-function(totalLRone,lexpsTinp,lexpsT,rexpsTinp,rexpsT){ #,lexpsTinp=lexpsTinp,lexpsT=lexpsT,rexpsTinp=rexpsTinp,rexpsT=rexpsT 
  totalLRone<-as.data.frame(totalLRone)
  inputL<-otherexp(totalLRone,lexpsTinp,lexpsT,"Ligand")$inputs
  lenL<-otherexp(totalLRone,lexpsTinp,lexpsT,"Ligand")$lens
  inputR<-otherexp(totalLRone,rexpsTinp,rexpsT,"Receptor")$inputs
  lenR<-otherexp(totalLRone,rexpsTinp,rexpsT,"Receptor")$lens
  
  set.seed(1)
  pval<-c()
  permres<-c()
  for(dd in 1:100){ #random 100times
    idl=sample(1:ncol(inputL),lenL,replace =T)
    idr=sample(1:ncol(inputR),lenR,replace =T)
    permres[dd]<-(sum(unlist(inputL[idl]))*sum(unlist(inputR[idr]))) #sum value
  }
  pval=(sum(permres>(totalLRone$Lexp*totalLRone$Rexp))/length(permres))#/2
  return(pval)
}

select_base_pvalone<-function(totalLR,lexpsTinp,lexpsT,rexpsTinp,rexpsT){ #,lexpsTinp=lexpsTinp,lexpsT=lexpsT,rexpsTinp=rexpsTinp,rexpsT=rexpsT 
  for(o in 1:dim(totalLR)[1]){
    totalLRone<-as.data.frame(totalLR[o,])
    inputL<-otherexp(totalLRone,lexpsTinp,lexpsT,"Ligand")$inputs
    lenL<-otherexp(totalLRone,lexpsTinp,lexpsT,"Ligand")$lens
    inputR<-otherexp(totalLRone,rexpsTinp,rexpsT,"Receptor")$inputs
    lenR<-otherexp(totalLRone,rexpsTinp,rexpsT,"Receptor")$lens
    
    set.seed(1)
    pval<-c()
    permres<-c()
    for(dd in 1:100){ #random 100times
      idl=sample(1:ncol(inputL),lenL,replace =T)
      idr=sample(1:ncol(inputR),lenR,replace =T)
      permres[dd]<-(sum(unlist(inputL[idl]))*sum(unlist(inputR[idr]))) #sum value
    }
    pval=(sum(permres>(totalLRone$Lexp*totalLRone$Rexp))/length(permres))#/2
    return(pval)
  }
}

single_network_plot<-function(kepLRpvalinp,mainlab,usedcolo){
  library(igraph)
  pdf(paste(resloc,mainlab,"net.pdf",sep=""))
  
  set.seed(200)
  plotinp0<-kepLRpvalinp[,colnames(kepLRpvalinp) %in% c("Lloc","Rloc")]
  plotinp0$val<-1
  plotinp<-aggregate(plotinp0$val,by=list(plotinp0$Lloc,plotinp0$Rloc),sum) 
  colnames(plotinp)<-c("from","to","edge")
  write.csv(plotinp,paste(resloc,mainlab,"netinput.csv",sep=""),quote = F)
  
  g <- graph_from_data_frame(plotinp, directed=TRUE)
  
  usedcolo1<-usedcolo[unique(c(plotinp$from,plotinp$to))]
  
  V(g)$color <-usedcolo1
  E(g)$width <-normalized(E(g)$edge)*10+1
  E(g)$arrow.size <- 0.3
  E(g)$edge.color <- "gray80"
  ##layout_nicely
  l <-do.call("layout_in_circle", list(g)) 
  plot(g,layout=l,margin=0.3,vertex.label.dist=2,edge.curved=0.5,vertex.frame.color=NA,main=mainlab)
  #strength---need to output
  inlink<-as.data.frame(strength(g, mode="in",weights = E(g)$edge))
  outlink<-as.data.frame(strength(g, mode="out",weights = E(g)$edge))
  totallink<-as.data.frame(strength(g, mode="total",weights = E(g)$edge))
  betweennesscore<-as.data.frame(betweenness(g, directed=T, weights=E(g)$edge))
  strengout<-as.data.frame(cbind(inlink,outlink,totallink,betweennesscore))
  colnames(strengout)<-c("incoming","outgoing","total","betweennesscore")
  rownames(strengout)<-paste(mainlab,rownames(strengout),sep = ":")
  write.csv(strengout,paste(resloc,mainlab,"netdetail.csv",sep=""),quote = F)
  
  #network based on hub
  hs <- hub_score(g, weights=E(g)$edge)$vector
  plot(g,margin=0.3,vertex.label.dist=2,edge.curved=0.5,layout=l,vertex.frame.color=NA, vertex.size=hs*20, main=paste(mainlab,"Hub net"))
  dev.off()
}

single_network_gene_plot<-function(kepLRpvalinp,usedgene,mainlab,usedcolo){
  library(igraph)
  pdf(paste(resloc,usedgene,mainlab,"-net.pdf",sep=""))
  
  set.seed(200)
  kepLRpvalinp1<-kepLRpvalinp
  inp0<-kepLRpvalinp1[(kepLRpvalinp$Lgen %in% usedgene | kepLRpvalinp$Rgen %in% usedgene),]
  plotinp0<-as.data.frame(kepLRpvalinp1[(kepLRpvalinp$Lgen %in% usedgene | kepLRpvalinp$Rgen %in% usedgene),colnames(kepLRpvalinp) %in% c("Lloc","Rloc")])
  plotinp0$LRgene<-paste(inp0$Lgen,inp0$Rgen,sep=":")
  plotinp0$val<-1
  plotinp<-aggregate(plotinp0$val,by=list(plotinp0$Lloc,plotinp0$Rloc),sum) 
  for(s in 1:dim(plotinp)[1]){
    plotinp[s,4]=paste(plotinp0$LRgene[plotinp0$Lloc==plotinp$from[s] & plotinp0$Rloc==plotinp$to[s]],collapse = "/")
  }
  colnames(plotinp)<-c("from","to","edge","label")
  g <- graph_from_data_frame(plotinp[,1:3], directed=TRUE)
  
  usedcolo1<-usedcolo[unique(c(plotinp$from,plotinp$to))]
  
  V(g)$color <-usedcolo1
  E(g)$width <-normalized(E(g)$edge)*10+1
  E(g)$arrow.size <- 0.3
  E(g)$edge.color <- "gray80"
  ##layout_nicely
  l <-do.call("layout_in_circle", list(g))
  plot(g,layout=l,margin=0.3,vertex.label.dist=2,edge.curved=0.5,vertex.frame.color=NA,main=mainlab)
  write.csv(plotinp,paste(resloc,usedgene,mainlab,"-netdetail.csv",sep=""),quote = F)
  
  #network based on hub
  hs <- hub_score(g, weights=E(g)$edge)$vector
  plot(g,margin=0.3,vertex.label.dist=2,edge.curved=0.5,layout=l,vertex.frame.color=NA, vertex.size=hs*20, main=paste(mainlab,"Hub net"))
  dev.off()
  #}
}

library(tseries)
tscorrelation<-function(inp1sd,inp2sd,dataL,dataR,Lnam,Rnam){
  d=0
  restmp<-as.data.frame(matrix(NA,nr=1,nc=5))
  colnames(restmp)<-c("Ligand","Receptor","p","r","L:R")
  for(r in 1:ncol(inp1sd)){
    for(c in 1:ncol(inp2sd)){
      seirescor<-ccf(inp1sd[,r],inp2sd[,c],lag.max = 1,plot = F) #time-series correlation
      max.cor<-seirescor$acf[which.max(seirescor$acf)]
      pval<- (2 * (1 - pnorm(abs(max.cor), mean = 0, sd = 1/sqrt(seirescor$n.used))))
      if(pval<0.05){
        d=d+1
        restmp[d,1]=Lnam #sub("\\.[0-9]+$","",as.character(Lnam)) #ligand
        restmp[d,2]=Rnam #sub("\\.[0-9]+$","",as.character(Rnam)) #Receptor
        restmp[d,3]=pval #p
        restmp[d,4]=max.cor #r
        restmp[d,5]=paste(colnames(inp1sd)[r],colnames(inp2sd)[c],sep=":") #cell type nam L:R
      }
    }
  }
  return(restmp)
}

#stat_LRcor(data1,data2,ytim)
stat_LRcor<-function(dataL,dataR,dattim){
  library(Hmisc)
  tim<-as.character(unique(dattim$Time[order(dattim$Order)]))
  for(i in 1:length(unique(dataL$variable))){ #one LR gene
    inp1n<-as.data.frame(dataL[as.character(dataL$variable)==unique(dataL$variable)[i] ,])
    inp2n<-as.data.frame(dataR[as.character(dataL$variable)==unique(dataL$variable)[i] ,])
    
    inp1<-reshape2::dcast(inp1n,Group.2~Group.1) #time~celltype
    inp1s<-inp1[,-1]
    rownames(inp1s)<-inp1[,1]
    inp1s[is.na(inp1s)]=0
    inp1sord<-inp1s[tim,]
    inp2<-reshape2::dcast(inp2n,Group.2~Group.1) #time~celltype
    inp2s<-inp2[,-1]
    rownames(inp2s)<-inp2[,1]
    inp2s[is.na(inp2s)]=0
    inp2sord<-inp2s[tim,]
    
    insd1 = apply(inp1sord, 2, sd, na.rm = TRUE)
    insd2 = apply(inp2sord, 2, sd, na.rm = TRUE)
    
    inp1sd<-as.data.frame(inp1sord[,insd1>0.01]) #0.2
    inp2sd<-as.data.frame(inp2sord[,insd2>0.01]) #remove all equal to zero; sd equal to zero
    
    if(dim(inp1sd)[2]>=1 & dim(inp2sd)[2]>=1){ #if variable >=1 ,else didn't do it
      rownames(inp1sd)<-rownames(inp1sord)
      colnames(inp1sd)<-colnames(inp1sord)[insd1>0.01]#0.2
      rownames(inp2sd)<-rownames(inp2sord)
      colnames(inp2sd)<-colnames(inp1sord)[insd2>0.01]
      
        restmp<-tscorrelation(inp1sd,inp2sd,dataL,dataR,as.character(unique(dataL$variable)[i]),as.character(unique(dataR$variable)[i]))
        if(i==1){res<-restmp}else{res<-rbind(res,restmp)}
      }
  }
  write.csv(na.omit(res),paste(resloc,"significant_LRcor-series.csv",sep=""),quote = F,row.names = F)
  
  return(na.omit(res))
  }

#plot_LR_exps_label(data1,data2,sigres,ytim,usedcolo)
plot_LR_exps_label<-function(dataL,dataR,sigres,dattim,usedcolo){ 
  library(ggpubr)
  pdf(paste(resloc,"plot_LR_exps_line.pdf",sep = ""))
  for(i in 1:length(unique(dataL$variable))){ 
    inp1n<-as.data.frame(dataL[as.character(dataL$variable)==as.character(unique(dataL$variable)[i]) ,])
    tim<-as.character(unique(dattim$Time[order(dattim$Order)]))
    timord<-as.numeric(unique(dattim$Order[order(dattim$Order)]))
    inp1n$Group.2<-factor(inp1n$Group.2,levels =tim)
    inp1n$Group.2<-as.numeric(inp1n$Group.2)
    siginp<-as.data.frame(sigres[sigres$Ligand==as.character(unique(dataL$variable)[i]) & sigres$Receptor==as.character(unique(dataR$variable)[i]),])
    inp1n$variable<-as.character(inp1n$variable)
    usedcolo1<-usedcolo[unique(inp1n$Group.1)] #log()
    p1<-ggplot(data=inp1n,mapping=aes(x=Group.2,y=value,colour = Group.1))+ geom_point()+theme_classic()+ geom_line()+ scale_x_continuous(breaks=timord, labels=tim)+labs(title=sub("\\.[0-9]+$","",as.character(unique(dataL$variable)[i])),y="Expression of Ligand",x="Time")+theme(axis.title.y =element_text(size=10),axis.text.x  =element_text(angle = 15),legend.position = "none")+scale_color_manual(values=usedcolo1,name="Type") #+theme(legend.position="none")
    
    if(dim(siginp)[1]==0){
      p2<-NULL
    }else{
      p2<-ggtexttable(siginp, rows = NULL, theme = ttheme("light"))
    }
    
    inp2n<-as.data.frame(dataR[as.character(dataR$variable)==as.character(unique(dataR$variable)[i]) ,])
    inp2n$Group.2<-factor(inp2n$Group.2,levels =tim)
    inp2n$Group.2<-as.numeric(inp2n$Group.2)
    usedcolo1<-usedcolo[unique(inp2n$Group.1)] #log()
    p3<-ggplot(data=inp2n,mapping=aes(x=Group.2,y=value,colour = Group.1))+ geom_point()+theme_classic()+ geom_line()+ scale_x_continuous(breaks=timord, labels=tim)+labs(title=sub("\\.[0-9]+$","",as.character(unique(dataR$variable)[i])),y="Expression of Receptor",x="Time")+theme(axis.title.y =element_text(size=10),legend.position = "none")+scale_color_manual(values=usedcolo1,name="Type")+theme(axis.text.x  =element_text(angle = 15))
    
    p<-ggarrange(p2,
                 ggarrange(p1, p3, ncol = 2, labels = c("B", "C")),
                 nrow = 2,
                 labels = "A", heights  = c(0.8,1.9)) 
    
    print(p)
    if(i==1|i==2|i==3){
      usedcolo1<-usedcolo[unique(inp2n$Group.1)]  
      p0<-ggplot(data=inp2n,mapping=aes(x=Group.2,y=log(value),colour = Group.1))+ geom_point()+theme_classic()+ geom_line()+ scale_x_continuous(breaks=timord, labels=tim)+labs(title=sub("\\.[0-9]+$","",as.character(unique(dataR$variable)[i])),y="Log transformed expression of Receptor",x="Time")+theme(axis.title.y =element_text(size=10))+scale_color_manual(values=usedcolo1,name="Type")
      print(p0)  
    }
  }
  dev.off()
}

compare_network_plot<-function(kepLRpval,controltime,usedcolo){
  controlinp<-kepLRpval[kepLRpval$time==controltime,]
  otherinp<-kepLRpval[kepLRpval$time!=controltime,]
  for(t in 1:length(unique(otherinp$time))){
    tmpinp<-otherinp[otherinp$time==unique(otherinp$time)[t],]
    incinp<-tmpinp[!((tmpinp$Lloc %in% controlinp$Lloc) & (tmpinp$Rloc %in% controlinp$Rloc) & (tmpinp$Lgen %in% controlinp$Lgen) & (tmpinp$Rgen %in% controlinp$Rgen)),]
    write.csv(incinp,paste(resloc,unique(otherinp$time)[t],"vs",controltime,"-comparenet-increased.csv",sep=""),quote = F,row.names = F)
    decinp<-controlinp[!((controlinp$Lloc %in% tmpinp$Lloc) & (controlinp$Rloc %in% tmpinp$Rloc) & (controlinp$Lgen %in% tmpinp$Lgen) & (controlinp$Rgen %in% tmpinp$Rgen)),]
    write.csv(decinp,paste(resloc,unique(otherinp$time)[t],"vs",controltime,"-comparenet-decreased.csv",sep=""),quote = F,row.names = F)
    
    single_network_plot(incinp,paste("Compared with",controltime,"network in",unique(otherinp$time)[t]),usedcolo)
  }
}

dot_exp_pval<-function(kepLRpval,dattimpval){
  pdf(paste(resloc,"plot_LR_exps_dot.pdf",sep = ""))
  dotinp<-kepLRpval[,colnames(kepLRpval) %in% c("time","pval")]
  dotinp$LRgene<-paste(kepLRpval$Lgen,kepLRpval$Rgen,sep=":")
  dotinp$LRloc<-paste(kepLRpval$Lloc,kepLRpval$Rloc,sep=":")
  dotinp$LRexp<-kepLRpval$Lexp*kepLRpval$Rexp #time,LRgene,LRloc,LRexp
  tim<-as.character(unique(dattimpval$Time[order(dattimpval$Order)]))
  timord<-unique(dattimpval$Order[order(dattimpval$Order)])
  dotinp$time<-factor(dotinp$time,levels =tim)
  
  p1<-ggplot(dotinp, aes(time, LRgene)) + geom_point(aes(size=-log10(dotinp$LRexp+0.000001),color=dotinp$pval))+scale_size_continuous(range=c(0.1,3))+ facet_wrap( ~ dotinp$LRloc)+ theme(axis.text.y = element_text(size = 7),strip.text = element_text(size = 7),axis.text.x=element_text(face="bold",size=8,angle=-45))+theme(strip.background = element_blank(), strip.placement = "outside",legend.title=element_text("pvalue"))+labs(x="Time",y="Ligand:Receptor",color="pval",size="Exp")#+ scale_x_continuous(breaks=timord, labels=tim) 
  p1
  dev.off()
}

random_type_treat<-function(datexp,dattim,dattyp){
  for(t in 1:length(unique(dattim$Time))){
    for(c in 1:length(unique(dattyp$Type))){
      in0<-datexp[,dattim$Time==unique(dattim$Time)[t] & dattyp$Type==unique(dattyp$Type)[c]]
      for(i in 1:10){
        a <- rowSums(inn0[, sample(1:ncol(inn0), round(ncol(inn0)*0.5))], na.rm = T)
        if(i == 1){
          id_tmp <- data.frame(exp = a)
        }else{
          id_tmp <- cbind.data.frame(id_tmp, as.data.frame(a))
        }
      }
      colnames(id_tmp) <- paste0(as.character(unique(dattim$Time)[t]),":",as.character(unique(dattyp$Type)[c]),":", 1:100)
    }
    if(t==1){
      totdat<-id_tmp
    }else{
      totdat<-cbind.data.frame(totdat,id_tmp)
    }
  }
  return(totdat)
}

heat_cellLR<-function(totdat,celltypeL,celltypeR,pairs,dattim){
  types<-sapply(strsplit(colnames(totdat)),"[[",2)
  times<-sapply(strsplit(colnames(totdat)),"[[",1)
  heatinpL0<-totdat[rownames(totdat)%in% unique(unlist(pairs[,1])), types==celltypeL]
  dattimL0<-times[types==celltypeL]
  heatinpR0<-totdat[rownames(totdat)%in% unique(unlist(pairs[,2])), types==celltypeR]
  dattimR0<-times[types==celltypeR]
  
  weekL<-dattimL0
  typeL<-celltypeL
  weekcol<-brewer.pal(9,"YlGn")
  names(weekcol)<-as.character(unique(dattim$Time[order(dattim$Order)]))
  typecol<-tsccnetcol
  names(typecol)<-as.character(unique(celltypeL))
  
  annotation_colL = data.frame(TypeClass = typeL,Week=weekL)
  rownames(annotation_col) = colnames(heatinpL0)
  ann_colors = list(TypeClass = typecol,Week = weekcol)
  
  pl<-pheatmap(heatinpL0,annotation_colors = ann_colors,annotation_col=annotation_colL,show_rownames=T,show_colnames=F,scale = "row",cluster_cols = F)
  
  weekR<-dattimR0
  typeR<-celltypeR
  annotation_colR = data.frame(TypeClass = typeR,Week=weekR)
  rownames(annotation_col) = colnames(heatinpR0)
  pr<-pheatmap(heatinpR0,annotation_colors = ann_colors,annotation_col=annotation_colR,show_rownames=T,show_colnames=F,scale = "row",cluster_cols = F)
  library(gridExtra)
  grid.arrange(pl, pr, nrow = 1)
}

preparelocation<-function(aimspecies,dbloc,mainlab,resloc){
  #b.just select the membrane and secreted protein(L) membrane(R) +trans LRdb into aimspecies genes
  memsercpros<-memserchomotrans(mempros,sercpros,aimspecies)
  save(memsercpros,file=paste(resloc,mainlab,"-memsercpros.rds",sep=""))
  # print(paste("Membrane protein num is ",length(unique(memsercpros$memprot)),sep=""))
  # print(paste("Secreted protein num is ",length(unique(memsercpros$sercprot)),sep=""))
  return(memsercpros)
}

preparepairs<-function(yexp,memsercpros,aimspecies,dbloc,resloc,mainlab){
  #b.just select the membrane and secreted protein(L) membrane(R) +trans LRdb into aimspecies genes
  usedpairsdata<-LRdbhomotrans(yexp,memsercpros$memprot,memsercpros$sercprot,aimspecies,dbloc)
  print(paste("Total L&R pairs is ",dim(usedpairsdata)[1],"; Total Ligand genes ",length(unique(usedpairsdata[,1])),"; Total Receptor genes ",length(unique(usedpairsdata[,2])),sep=" "))
  write.csv(usedpairsdata,paste(resloc,mainlab,"-usedpairs.csv",sep=""),quote = F)
  return(usedpairsdata)
}

#d.genes in each cell type,each time point mean value
expstat<-function(exps,ytyp,ytim,ytypnam,ytimnam,memsercpros,resloc,genetype){
  expcontain<-list()
  expsT0<-as.data.frame(t(exps))
  expsT0$id=rownames(expsT0)
  ytyp$id=rownames(ytyp)
  ytim$id=rownames(ytim) 
  
  expsT1<-merge(expsT0,ytyp,by="id")
  expsT2<-merge(expsT1,ytim,by="id") 
  expsT<-expsT2[,-1] #Type Time Order
  rownames(expsT)<-expsT2[,1]
  expcontain$expsT<-expsT
  
  g<-sub("\\.[0-9]+","",colnames(expsT))
  gorder<-colnames(expsT)[!colnames(expsT) %in% c(ytypnam,ytimnam,"Order") ]
  in1<-expsT[,g %in% c(unique(memsercpros$memprot),ytypnam,ytimnam,"Order")] #membrane
  in2<-expsT[,g %in% c(unique(memsercpros$sercprot),ytypnam,ytimnam,"Order")] #secreted
  expsTa1<-aggregate(in1[,!colnames(in1) %in% c(ytypnam,ytimnam,"Order")],by=list(in1[,colnames(in1)==ytypnam],in1[,colnames(in1)==ytimnam]),FUN=mean) #membrane
  expsTa2<-aggregate(in2[,!colnames(in2) %in% c(ytypnam,ytimnam,"Order")],by=list(in2[,colnames(in2)==ytypnam],in2[,colnames(in2)==ytimnam]),FUN=sum) #secreted
  all(expsTa1$Group.1==expsTa2$Group.1)
  all(expsTa1$Group.2==expsTa2$Group.2)
  expsTam0<-cbind(expsTa1,expsTa2[,-c(1,2)])
  expsTam1<-expsTam0[,c("Group.1","Group.2",gorder)]
  expsTa<-expsTam1
  data0<-melt(expsTa,id.var=c("Group.1","Group.2"))
  write.csv(data0,paste(resloc,"tmp/",genetype,"data.csv",sep=""),quote = F,row.names = F)
  
  tmp0<-data0 %>% split(list(.$Group.2,.$variable)) %>% map_df(.,select_base_exp)
  expcontain$tmp0<-tmp0
  return(expcontain)
  
}

singlenet_exp<-function(yexp,ytyp,ytypnam,ytim,ytimnam,memsercpros,usedpairsdata,usedcolo,scaled,dbloc,mainlab,resloc){
  #c.filtering:expressed at least in ten cell,log2 transform
  lexp<-na.omit(yexp[usedpairsdata[,1],])#) 
  rexp<-na.omit(yexp[usedpairsdata[,2],])#)
  print(paste("a.Used L&R pairs is ",dim(lexp)[1],sep=" "))
  if(scaled=="TRUE" | scaled=="True"){
    keepl<-rowSums(lexp > 0) >=10  
    keepr<-rowSums(rexp >0) >=10 
    lexps<-log((lexp[keepl & keepr,]+1),base=2) 
    rexps<-log((rexp[keepr & keepl,]+1),base=2)
  }else if(scaled=="FALSE" | scaled=="False"){
    lexps<-lexp
    rexps<-rexp  
  }
  print(paste("Used L&R pairs is ",dim(lexps)[1],"; Total cell num is",dim(lexps)[2],sep=" "))
  
  Lexpcontain<-expstat(lexps,ytyp,ytim,ytypnam,ytimnam,memsercpros,resloc,"Ligand")
  Rexpcontain<-expstat(rexps,ytyp,ytim,ytypnam,ytimnam,memsercpros,resloc,"Receptor")
  Ltmp0<-Lexpcontain$tmp0
  Rtmp0<-Rexpcontain$tmp0
  nanumL<-apply(Ltmp0, 1, function(x){sum(is.na(x))})
  nanumR<-apply(Rtmp0, 1, function(x){sum(is.na(x))})
  Ltmp<-Ltmp0[nanumL!=4 & nanumR!=4,]
  Rtmp<-Rtmp0[nanumL!=4 & nanumR!=4,]
  colnames(Ltmp)<-c("Group.1","Group.2","variable","value")
  colnames(Rtmp)<-c("Group.1","Group.2","variable","value")
  Ltmp$id<-paste(Ltmp$variable,Rtmp$variable,sep=":")
  Rtmp$id<-paste(Ltmp$variable,Rtmp$variable,sep=":")
  
  totalLR<-map2_df(Ltmp %>% split(list(Ltmp$Group.2,Ltmp$id)), Rtmp %>% split(list(Rtmp$Group.2,Rtmp$id)), select_base_exp_out)
  #g.pvalue statistic
  lexpsT<-Lexpcontain$expsT
  rexpsT<-Rexpcontain$expsT
  lexpsTinp<-lexpsT[1:nrow(lexps)] ##just pick cells! Type Time Order
  colnames(lexpsT)[(nrow(lexps)+1):length(colnames(lexpsT))]=c(colnames(ytyp),colnames(ytim))[c(colnames(ytyp),colnames(ytim)) !="id"]
  rexpsTinp<-rexpsT[1:nrow(rexps)]
  colnames(rexpsT)[(nrow(rexps)+1):length(colnames(rexpsT))]=c(colnames(ytyp),colnames(ytim))[c(colnames(ytyp),colnames(ytim)) !="id"]
  resexp<-list()
  resexp$totalLR<-totalLR
  resexp$lexpsT<-lexpsT
  resexp$rexpsT<-rexpsT
  resexp$lexpsTinp<-lexpsTinp
  resexp$rexpsTinp<-rexpsTinp
  return(resexp)
}

# ncores=4
singlenet_pval<-function(totalLR,pval,resloc){
  ###########################
  totalLRpval<-totalLR
  totalLRpval$pval<-pval
  
  kepLRpval<-na.omit(totalLRpval[totalLRpval$pval<=0.05,])
  write.csv(kepLRpval,paste(resloc,"singlenet.csv",sep=""),quote = F,row.names = F)
  print(paste("Find L&R connections",dim(totalLR)[1],sep=" "))
  print(paste("Find significant L&R connections",dim(kepLRpval)[1],sep=" "))
  #h.plot network for each network in each time #time,Lloc,Lgen,Lexp,Rloc,Rgen,Rexp,type,pval
  for(t in 1:length(unique(kepLRpval$time))){
    kepLRpvalinp<-kepLRpval[kepLRpval$time==unique(kepLRpval$time)[t],]
    write.csv(kepLRpvalinp,paste(resloc,unique(kepLRpval$time)[t],"-singlenet.csv",sep=""),quote = F,row.names = F)
    single_network_plot(kepLRpvalinp,unique(kepLRpval$time)[t],usedcolo)
  }
}

developcorrelation<-function(ytim,usedcolo,resloc){ #developcorrelation(inptim,usedcolo,resloc)
  data1<-read.csv(paste(resloc,"tmp/","Liganddata.csv",sep=""))
  data2<-read.csv(paste(resloc,"tmp/","Receptordata.csv",sep=""))
  #e.line plot during timepoint + correlation value during timepoint
  sigres<-stat_LRcor(data1,data2,ytim)
  plot_LR_exps_label(data1,data2,sigres,ytim,usedcolo) 
}

comparednet<-function(controltime,treattime,usedcolo,resloc){
  kepLRpval<-read.csv(paste(resloc,"singlenet.csv",sep=""))
  if(treattime!="total"){
    kepLRpval1<-kepLRpval[kepLRpval$time %in% c(controltime,treattime),]
  }else{
    kepLRpval1<-kepLRpval  
  }
  #k.compared network  
  compare_network_plot(kepLRpval1,controltime,usedcolo)
}

sankey<-function(time,type,usedcolo,mainlab,resloc){
  #sankey plot
  mergdat<-as.data.frame(prop.table(x = table(time,type), margin = 1))
  colnames(mergdat)<-c("Time","Type","Freq")
  mergdata<-mergdat[order(mergdat$Time),]
  s<-c()
  for(i in 1:length(unique(mergdata$Time))){
    if(i==1){
      s<-c(1:dim(mergdata[mergdata$Time==unique(mergdata$Time)[i],])[1])
    }else{
      s<-c(s,1:dim(mergdata[mergdata$Time==unique(mergdata$Time)[i],])[1])
    }
  }
  mergdata$subject<-s
  library(stringr)
  mergdata$Time<-factor(mergdata$Time,levels=str_sort(unique(mergdata$Time), numeric = TRUE))
  mergdata$Type<-factor(mergdata$Type,levels =unique(mergdata$Type))
  col1<-usedcolo[levels(mergdata$Type)]
  p<-ggplot(mergdata,
            aes(x = Time, stratum = Type, alluvium = subject,
                y = Freq,
                fill = Type)) + #, label = Type
    scale_x_discrete(expand = c(.1, .1)) +
    geom_flow() +
    geom_stratum(alpha = .5) +
    scale_fill_manual(values = col1)+
    ggtitle(mainlab)+theme_classic()
  pdf(paste(resloc,"sankey.pdf",sep=""))
  print(p+theme(axis.text.x =element_text(angle=30)))
  dev.off()
}

definecolo<-function(tsccnetcol,type,resloc,mainlab){
  #define color
  usedcolo<-tsccnetcol[1:length(unique(type))]
  names(usedcolo)<-unique(type)
  save(usedcolo,file=paste(resloc,mainlab,"-usedcolo.rdata",sep=""))
  return(usedcolo)
}

importance_plot<-function(resloc,ifscale,feature,columnorder){
  files<-list.files(path = resloc,pattern = "^Compared.*detail.csv")
  filenam<-sub("^Compared.*in ","",sub("netdetail.csv","",files))
  for(i in 1:length(files)){
    if(i==1){
      dat<-read.csv(paste(resloc,files[i],sep=""),row.names = 1)
      if(ifscale=="Column" |ifscale=="column" ){
        datas<-as.data.frame(scale(dat))
      }else{
        datas<-dat 
      }
    }else{
      dat0<-read.csv(paste(resloc,files[i],sep=""),row.names = 1)
      if(ifscale=="Column" | ifscale=="column"){
        datas0<-as.data.frame(scale(dat0))
      }else{
        datas0<-dat0 
      }
      datas<-rbind(datas,datas0)
    } 
  }
  print(paste("Have features: ",paste(colnames(datas),collapse = ", "),sep=""))
  #each time scale
  datas$Celltype<-sub(".*:","",rownames(datas))
  datas$Time<-sub("^Compared.*in ","",sub("netdetail.csv","",sub(":.*","",rownames(datas))))
  
  #input
  inp0<-reshape2::dcast(datas,Celltype~Time,value.var=feature)
  inp<-inp0[,-1]
  rownames(inp)<-inp0[,1]
  
  sdnum<-apply(inp, 1, sd)#, na.rm = TRUE
  inp1<-inp[sdnum !=0 & !is.na(sdnum),]
  if(columnorder=="None"){
    inps<-inp1  
  }else{
    inps<-inp1[,columnorder]
  }
  pdf(paste(resloc,"Importance-",feature,"-",ifscale,"scaled",".pdf",sep=""))
  if(ifscale=="row" | ifscale=="Row"){
    p<-pheatmap(inps,scale = "row",na_col = "gray",cluster_cols = F,treeheight_row = 0,angle_col=45, color = colorRampPalette(c("navy", "white", "firebrick3"))(100),border_color = NA,main = feature) #,gaps_col=c(1,2)
    print(p)
  }else{
    p<-pheatmap(inps,na_col = "gray",cluster_cols = F,treeheight_row = 0,angle_col=45, color = colorRampPalette(c("navy", "white", "firebrick3"))(100),border_color = NA,main = feature) #,gaps_col=c(1,2)
    print(p)
  }
  dev.off()
}

importance_plot_single<-function(resloc,ifscale,feature,columnorder,roworder){
  library(pheatmap)
  files<-list.files(path = resloc,pattern = "*netdetail.csv")
  filenam<-sub("netdetail.csv","",files)
  for(i in 1:length(files)){
    if(i==1){
      dat<-read.csv(paste(resloc,files[i],sep=""),row.names = 1)
      if(ifscale=="Column" |ifscale=="column" ){
        datas<-as.data.frame(scale(dat))
      }else{
        datas<-dat 
      }
    }else{
      dat0<-read.csv(paste(resloc,files[i],sep=""),row.names = 1)
      if(ifscale=="Column" | ifscale=="column"){
        datas0<-as.data.frame(scale(dat0))
      }else{
        datas0<-dat0 
      }
      datas<-rbind(datas,datas0)
    } 
  }
  print(paste("Have features: ",paste(colnames(datas),collapse = ", "),sep=""))
  #each time scale
  datas$Celltype<-sub(".*:","",rownames(datas))
  datas$Time<-sub("netdetail.csv","",sub(":.*","",rownames(datas)))
  
  #input
  inp0<-reshape2::dcast(datas,Celltype~Time,value.var=feature)
  inp<-inp0[,-1]
  rownames(inp)<-inp0[,1]
  inp1<-inp
  inp1[is.na(inp)]=0
  
  pdf(paste(resloc,"Importance-",feature,"-",ifscale,"scaled",".pdf",sep=""))
  
  if(columnorder[1]=="None" & roworder[1]=="None"){
    inps<-inp1
    mat<-log(inps+1) #log transform
    mat1<-t(scale(t(mat)))
    f1 = colorRamp2(c(min(mat1),median(unlist(mat1)),max(mat1)), c("#2D5B8D","#FFD3B6","#8E145B"))
    p<-Heatmap(mat1,col=f1,name = "Scaled Num",column_title =feature,cluster_rows=T,cluster_columns=F,show_row_dend=F,show_column_dend =F)
    print(p)
  }else if(columnorder[1]!="None" & roworder[1]=="None"){
    inps<-inp1[,columnorder]
    mat<-log(inps+1) #log transform
    mat1<-t(scale(t(mat)))
    f1 = colorRamp2(c(min(mat1),median(unlist(mat1)),max(mat1)), c("#2D5B8D","#FFD3B6","#8E145B"))
    p<-Heatmap(mat1,col=f1,name = "Scaled Num",column_title =feature,cluster_rows=F,column_order = columnorder,cluster_columns=F,show_row_dend=F,show_column_dend =F)
    print(p)
  }else if(columnorder[1]=="None" & roworder[1]!="None"){
    inps<-inp1[roworder,]
    mat<-log(inps+1) #log transform
    mat1<-t(scale(t(mat)))
    f1 = colorRamp2(c(min(mat1),median(unlist(mat1)),max(mat1)), c("#2D5B8D","#FFD3B6","#8E145B"))
    p<-Heatmap(mat1,col=f1,name = "Scaled Num",column_title =feature,cluster_rows=F,row_order = roworder,cluster_columns=F,show_row_dend=F,show_column_dend =F)
    print(p)
  }
  
  dev.off()
}

